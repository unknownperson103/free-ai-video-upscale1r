# Free AI Video Upscaler

A simple, quick and free no-nonsense tool for upscaling video with AI upscaling algorithms like [Anime4K](https://github.com/bloc97/Anime4K) right in your browser- no signups, no downloads just choose a video and download your upscaled video after it's done processing.

You can get started at 👉 https://free.upscaler.video/ 👈

<img src="https://github.com/sb2702/free-ai-video-upscaler/assets/5678502/60ed1132-b21d-4ecf-917d-f4ae831bb91c"  width="600" />

Based on my [WebSR](https://github.com/sb2702/websr) SDK.
